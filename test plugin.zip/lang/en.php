<?php
/**
 * English language file for pagestats plugin
 */

$lang['unit_mb'] = 'MB';

// Configuration descriptions
$lang['cacheTime'] = 'Cache lifetime in seconds (0 to disable caching)';
$lang['excludeNamespaces'] = 'Comma-separated list of namespaces to exclude from statistics';
$lang['showUnit'] = 'Show "MB" unit after size values';