<?php
/**
 * German language file for pagestats plugin
 */

$lang['unit_mb'] = 'MB';

// Configuration descriptions
$lang['cacheTime'] = 'Cache-Lebensdauer in Sekunden (0 zum Deaktivieren)';
$lang['excludeNamespaces'] = 'Kommagetrennte Liste von Namensräumen, die von den Statistiken ausgeschlossen werden sollen';
$lang['showUnit'] = 'Zeige "MB" Einheit nach Größenangaben';