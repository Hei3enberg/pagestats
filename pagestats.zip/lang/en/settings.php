<?php
/**
 * English configuration language file for pagestats plugin
 */

// Configuration descriptions
$lang['cacheTime'] = 'Cache lifetime in seconds (0 to disable caching)';
$lang['excludeNamespaces'] = 'Comma-separated list of namespaces to exclude from statistics';
$lang['showUnit'] = 'Show "MB" unit after size values';