<?php
/**
 * Deutsche Konfigurationssprache für pagestats plugin
 */

// Configuration descriptions
$lang['cacheTime'] = 'Cache-Lebensdauer in Sekunden (0 zum Deaktivieren)';
$lang['excludeNamespaces'] = 'Kommagetrennte Liste von Namensräumen, die von den Statistiken ausgeschlossen werden sollen';
$lang['showUnit'] = 'Zeige "MB" Einheit nach Größenangaben';