<?php
/**
 * Default settings for the pagestats plugin
 */

$conf['cacheTime'] = 3600; // 1 hour in seconds
$conf['excludeNamespaces'] = '';
$conf['showUnit'] = 1;